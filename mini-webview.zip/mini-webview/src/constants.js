const tags = ['A', 'BUTTON', 'INPUT', 'TEXTAREA', 'LABEL'];
const keys = ['Enter', 'TAB'];

export {
  tags,
  keys
};
